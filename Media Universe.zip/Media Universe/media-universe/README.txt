MEDIA UNIVERSE PLUS — PROJE NOTLARI

Başlatma:
1. ZIP dosyasını bir klasöre çıkartın.
2. media-universe/index.html dosyasını Chrome, Edge veya Firefox ile açın.
3. İnternet bağlantısı yalnızca Google Fonts ve harita gömmesi için gereklidir.

Eklenenler:
- Genişletilmiş ürün kataloğu ve kategori/marka filtreleri
- Ürün arama ve sıralama (fiyat, alfabetik)
- Favori ürün listesi (localStorage)
- Sepet ve miktar güncelleme
- Ürün detay penceresi
- En fazla 3 ürünü karşılaştırma
- Koyu/açık tema
- Kampanya görsel kaydırıcısı
- Alışveriş rehberi ve SSS
- Mobil uyumlu tasarım

Önemli:
Bu bir eğitim/portföy amaçlı ön yüz demosudur. Ürünler, fiyatlar, stoklar ve kampanyalar örnektir.
Gerçek ödeme, kullanıcı hesabı, sipariş kaydı veya iletişim formu sunucuya bağlı değildir.
Gerçek müşterilerden kart bilgisi toplamayın. Gerçek satış için güvenli bir backend ve ödeme sağlayıcısı entegrasyonu gerekir.
